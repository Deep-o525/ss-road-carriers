import { useRef, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import * as THREE from 'three'

export const sceneState = { p: 0, active: true, mx: 0, my: 0, invalidate: null }

const mat = (color, o = {}) => <meshStandardMaterial color={color} roughness={0.5} metalness={0.4} {...o} />
function Box({ p, s, c, o, cast = true }) {
  return <mesh position={p} castShadow={cast} receiveShadow><boxGeometry args={s} />{mat(c, o)}</mesh>
}
function Wheel({ p, spin }) {
  const g = useRef()
  useFrame((_, dt) => { if (g.current) g.current.rotation.x -= dt * 7 })
  return (
    <group position={p}><group ref={g}>
      <mesh rotation={[0, 0, Math.PI / 2]} castShadow><cylinderGeometry args={[0.46, 0.46, 0.4, 28]} />{mat('#0a0a0a', { roughness: 0.9, metalness: 0 })}</mesh>
      <mesh rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.24, 0.24, 0.42, 6]} />{mat('#8a8a8a', { metalness: 0.9, roughness: 0.3 })}</mesh>
    </group></group>
  )
}
function Truck() {
  const g = useRef()
  useFrame((s, dt) => {
    const { p, mx, my } = sceneState, mobile = s.size.width < 800
    const k = 1 - Math.pow(0.001, dt)
    const t = g.current
    t.rotation.y += ((-0.75 + p * 1.9 + mx * 0.22) - t.rotation.y) * k
    t.rotation.x += ((my * 0.04) - t.rotation.x) * k
    t.position.x += (((mobile ? 0 : 1.9) + p * 3) - t.position.x) * k
    t.position.y += (((mobile ? -0.9 : -0.2) - p * 0.6) - t.position.y) * k
    t.scale.setScalar(mobile ? 0.62 : 0.95)
    s.camera.position.x += ((6.5 + mx * 0.8) - s.camera.position.x) * 0.05
    s.camera.lookAt(0, 1.1, 0)
    if (sceneState.active) s.invalidate()
  })
  return (
    <group ref={g}>
      <Box p={[0, 0.7, -0.4]} s={[1.7, 0.3, 7.4]} c="#111" />
      <Box p={[0, 1.65, 2.4]} s={[1.95, 1.9, 1.7]} c="#1b1b1d" o={{ metalness: 0.7, roughness: 0.25 }} />
      <Box p={[0, 2.15, 3.255]} s={[1.6, 0.8, 0.02]} c="#05080c" o={{ metalness: 1, roughness: 0.05 }} cast={false} />
      <Box p={[0, 1.2, 3.26]} s={[1.5, 0.1, 0.06]} c="#ff6a1a" o={{ emissive: '#ff6a1a', emissiveIntensity: 0.6 }} cast={false} />
      <Box p={[0, 0.95, 3.3]} s={[1.9, 0.28, 0.2]} c="#0d0d0d" />
      {[-0.7, 0.7].map(x => <Box key={x} p={[x, 1.55, 3.27]} s={[0.35, 0.18, 0.04]} c="#fff" o={{ emissive: '#ffe2c0', emissiveIntensity: 2.5 }} cast={false} />)}
      <Box p={[0, 1.55, 0.2]} s={[2.1, 2.6, 5.2]} c="#242427" o={{ metalness: 0.55, roughness: 0.4 }} />
      {[-1.06, 1.06].map(x => <Box key={x} p={[x, 1.1, 0.2]} s={[0.02, 0.22, 5.2]} c="#ff6a1a" o={{ emissive: '#ff6a1a', emissiveIntensity: 0.45 }} cast={false} />)}
      {[-1.06, 1.06].map(x => <Box key={'l' + x} p={[x, 2.1, 0.2]} s={[0.02, 0.04, 5.2]} c="#ff6a1a" cast={false} />)}
      <Box p={[0, 1.55, -2.41]} s={[2.0, 2.4, 0.04]} c="#18181a" />
      {[-1, 1].map(x => [2.4, -0.4, -1.5, -2.6].map((z, i) => <Wheel key={x + '' + i} p={[x * 0.98, 0.47, z]} />))}
      <pointLight position={[0, 1.5, 4.6]} color="#ffb070" intensity={18} distance={9} />
    </group>
  )
}
function Road() {
  const g = useRef()
  useFrame((_, dt) => { g.current.children.forEach(m => { m.position.z -= dt * 7; if (m.position.z < -16) m.position.z += 32 }) })
  return (
    <>
      <mesh rotation-x={-Math.PI / 2} receiveShadow><planeGeometry args={[60, 60]} /><meshStandardMaterial color="#0b0b0c" roughness={0.35} metalness={0.6} /></mesh>
      <group ref={g}>{Array.from({ length: 22 }, (_, i) => <mesh key={i} position={[(i % 2 ? 3.4 : -3.4), 0.01, -16 + Math.floor(i / 2) * 3]} rotation-x={-Math.PI / 2}><planeGeometry args={[0.12, 1.4]} /><meshBasicMaterial color="#ff6a1a" /></mesh>)}</group>
    </>
  )
}
function Embers({ n = 260 }) {
  const ref = useRef()
  const pos = useMemo(() => { const a = new Float32Array(n * 3); for (let i = 0; i < n; i++) { a[i * 3] = (Math.random() - .5) * 18; a[i * 3 + 1] = Math.random() * 7; a[i * 3 + 2] = (Math.random() - .5) * 18 } return a }, [n])
  useFrame((_, dt) => {
    const a = ref.current.geometry.attributes.position.array
    for (let i = 0; i < n; i++) { a[i * 3 + 1] += dt * 0.35; a[i * 3 + 2] -= dt * 1.2; if (a[i * 3 + 1] > 7) a[i * 3 + 1] = 0; if (a[i * 3 + 2] < -9) a[i * 3 + 2] = 9 }
    ref.current.geometry.attributes.position.needsUpdate = true
  })
  return <points ref={ref}><bufferGeometry><bufferAttribute attach="attributes-position" count={n} array={pos} itemSize={3} /></bufferGeometry><pointsMaterial color="#ff8a3d" size={0.045} transparent opacity={0.8} depthWrite={false} blending={THREE.AdditiveBlending} /></points>
}
export default function Scene({ onReady }) {
  return (
    <Canvas id="scene" shadows frameloop="demand" dpr={[1, 1.6]} camera={{ position: [6.5, 3.2, 8.5], fov: 34 }}
      gl={{ antialias: true, powerPreference: 'high-performance' }}
      onCreated={({ gl, scene, invalidate }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping; gl.toneMappingExposure = 1.1
        scene.fog = new THREE.Fog('#0a0a0b', 9, 26); sceneState.invalidate = invalidate; onReady?.()
      }}>
      <color attach="background" args={['#0a0a0b']} />
      <ambientLight intensity={0.35} />
      <directionalLight position={[5, 8, 4]} intensity={1.6} castShadow shadow-mapSize={[1024, 1024]} shadow-camera-left={-8} shadow-camera-right={8} shadow-camera-top={8} shadow-camera-bottom={-8} />
      <spotLight position={[-6, 5, -5]} color="#ff6a1a" intensity={260} angle={0.6} penumbra={1} />
      <Truck /><Road /><Embers />
    </Canvas>
  )
}
