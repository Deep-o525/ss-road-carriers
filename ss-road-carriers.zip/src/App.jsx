import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Lenis from 'lenis'
import Scene, { sceneState } from './Scene'
import Network from './Network'
gsap.registerPlugin(ScrollTrigger)

// Set show:true on Warehousing only if it is a real operation.
const SERVICES = [
  { n: '01', t: 'Transportation', d: 'Dependable road transport for your consignments, planned around your schedule.', show: true },
  { n: '02', t: 'Freight Movement', d: 'Full-load and part-load freight movement between business locations.', show: true },
  { n: '03', t: 'Logistics Solutions', d: 'Coordinated planning and tracking tailored to how your business ships.', show: true },
  { n: '04', t: 'Warehousing', d: 'Storage and handling support.', show: false },
].filter(s => s.show)
const WHY = [
  ['Reliability', 'Commitments kept, schedules respected, communication that does not go quiet.'],
  ['Professional service', 'A disciplined team that treats every consignment as a responsibility.'],
  ['Efficient transportation', 'Sensible routing and loading to keep cost and transit time in check.'],
  ['Customer-focused', 'One accountable point of contact and flexibility around your needs.'],
]
const ABOUT = 'S.S. Road Carriers is a road transportation and logistics company built on a simple idea: businesses grow when their goods arrive on time. We move freight with care, plan with honesty, and treat every customer as a long-term partner. [Add your founding year, story and leadership here.]'

function Loader({ done }) {
  const [n, setN] = useState(0)
  useEffect(() => { const o = { v: 0 }; gsap.to(o, { v: 100, duration: 2, ease: 'power2.inOut', onUpdate: () => setN(Math.round(o.v)) }) }, [])
  return (
    <div className={'loader' + (done ? ' out' : '')}>
      <div className="loader-brand">S.S. <b>ROAD</b> CARRIERS</div>
      <div className="loader-bar"><i style={{ width: n + '%' }} /></div>
      <div className="loader-n">{String(n).padStart(3, '0')}</div>
    </div>
  )
}

export default function App() {
  const [ready, setReady] = useState(false)
  const [done, setDone] = useState(false)
  const [menu, setMenu] = useState(false)
  const [sent, setSent] = useState(false)
  const lenis = useRef(null)
  const root = useRef(null)

  useEffect(() => { const t = setTimeout(() => ready && setDone(true), 2300); return () => clearTimeout(t) }, [ready])
  useEffect(() => { const t = setTimeout(() => setDone(true), 6000); return () => clearTimeout(t) }, [])

  useEffect(() => {
    const l = new Lenis({ lerp: 0.09 }); lenis.current = l
    l.on('scroll', ScrollTrigger.update)
    const tick = t => l.raf(t * 1000); gsap.ticker.add(tick); gsap.ticker.lagSmoothing(0)
    const mm = e => { sceneState.mx = e.clientX / innerWidth - 0.5; sceneState.my = e.clientY / innerHeight - 0.5; sceneState.invalidate?.() }
    addEventListener('mousemove', mm)
    return () => { gsap.ticker.remove(tick); l.destroy(); removeEventListener('mousemove', mm) }
  }, [])

  useEffect(() => {
    if (!done) return
    const ctx = gsap.context(() => {
      gsap.from('.hl span', { yPercent: 110, duration: 1.2, stagger: 0.12, ease: 'power4.out' })
      gsap.from('.hero-fade', { opacity: 0, y: 30, duration: 1, delay: 0.6, stagger: 0.12, ease: 'power3.out' })
      ScrollTrigger.create({ trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true,
        onUpdate: s => { sceneState.p = s.progress; document.getElementById('scene').style.opacity = Math.max(0, 1 - s.progress * 1.15) },
        onToggle: s => { sceneState.active = s.isActive; if (s.isActive) sceneState.invalidate?.() } })
      gsap.utils.toArray('.rv').forEach(el => gsap.from(el, { y: 50, opacity: 0, duration: 1, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 88%' } }))
      gsap.fromTo('.about-text .w', { opacity: 0.12 }, { opacity: 1, stagger: 0.1, ease: 'none', scrollTrigger: { trigger: '.about-text', start: 'top 80%', end: 'bottom 45%', scrub: true } })
      gsap.to('.route', { strokeDashoffset: 0, duration: 2.2, stagger: 0.2, ease: 'power2.inOut', scrollTrigger: { trigger: '.net', start: 'top 75%' } })
      gsap.utils.toArray('.why-line').forEach(el => gsap.fromTo(el, { scaleX: 0 }, { scaleX: 1, transformOrigin: 'left', ease: 'power3.out', duration: 1.2, scrollTrigger: { trigger: el, start: 'top 90%' } }))
    }, root)
    return () => ctx.revert()
  }, [done])

  const go = (id) => e => { e.preventDefault(); setMenu(false); lenis.current?.scrollTo(id, { offset: -10 }) }
  const tilt = e => { const c = e.currentTarget, r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height
    c.style.setProperty('--mx', x * 100 + '%'); c.style.setProperty('--my', y * 100 + '%'); c.style.transform = `perspective(800px) rotateY(${(x - .5) * 8}deg) rotateX(${(.5 - y) * 8}deg)` }
  const untilt = e => { e.currentTarget.style.transform = '' }
  const submit = e => { e.preventDefault(); setSent(true) /* TODO: connect to your backend / email service */ }

  return (
    <div ref={root}>
      <Loader done={done} />
      <Scene onReady={() => setReady(true)} />
      <header className="nav">
        <a href="#top" className="logo" onClick={go(0)}>S.S. <b>ROAD</b> CARRIERS</a>
        <nav className={menu ? 'open' : ''}>
          {[['about', 'About'], ['services', 'Services'], ['network', 'Network'], ['why', 'Why us'], ['contact', 'Contact']].map(([id, l]) => <a key={id} href={'#' + id} onClick={go('#' + id)}>{l}</a>)}
        </nav>
        <button className="burger" aria-label="Menu" onClick={() => setMenu(m => !m)}><i /><i /></button>
      </header>

      <main>
        <section className="hero" id="top">
          <div className="hero-copy">
            <p className="eyebrow hero-fade">S.S. Road Carriers — Logistics &amp; Transportation</p>
            <h1 className="hl"><div><span>MOVING INDIA.</span></div><div><span className="o">CONNECTING</span></div><div><span>BUSINESSES.</span></div></h1>
            <p className="sub hero-fade">Reliable road logistics and freight transportation, engineered around your schedule and your trust.</p>
            <div className="ctas hero-fade">
              <a className="btn solid" href="#services" onClick={go('#services')}>Explore Our Services</a>
              <a className="btn" href="#contact" onClick={go('#contact')}>Contact Us</a>
            </div>
          </div>
          <div className="scroll-hint hero-fade">Scroll<i /></div>
        </section>

        <section className="sec about" id="about">
          <p className="eyebrow rv">About us</p>
          <p className="about-text">{ABOUT.split(' ').map((w, i) => <span className="w" key={i}>{w} </span>)}</p>
        </section>

        <section className="sec" id="services">
          <p className="eyebrow rv">Our services</p>
          <h2 className="rv">What we move,<br /><span className="o">and how.</span></h2>
          <div className="cards">
            {SERVICES.map(s => (
              <article className="card rv" key={s.n} onMouseMove={tilt} onMouseLeave={untilt}>
                <span className="num">{s.n}</span><h3>{s.t}</h3><p>{s.d}</p><span className="arrow">↗</span>
              </article>))}
          </div>
        </section>

        <section className="sec" id="network">
          <p className="eyebrow rv">Our network</p>
          <h2 className="rv">Connected,<br /><span className="o">lane by lane.</span></h2>
          <div className="netwrap rv"><Network /></div>
          <p className="note rv">Illustrative visualization. Hub names and routes are placeholders — replace with your real operating locations.</p>
        </section>

        <section className="sec" id="why">
          <p className="eyebrow rv">Why choose us</p>
          <h2 className="rv">Built on<br /><span className="o">trust.</span></h2>
          <div className="why">
            {WHY.map(([t, d], i) => (
              <div className="why-row" key={t}><div className="why-line" />
                <span className="num">0{i + 1}</span><h3>{t}</h3><p>{d}</p></div>))}
          </div>
        </section>

        <section className="sec contact" id="contact">
          <div>
            <p className="eyebrow rv">Contact</p>
            <h2 className="rv">Let's move<br /><span className="o">your freight.</span></h2>
            <ul className="details rv">
              <li><small>Phone</small>+91 XXXXX XXXXX</li>
              <li><small>Email</small>info@yourdomain.com</li>
              <li><small>Office</small>Registered office address — to be added</li>
              <li><small>Hours</small>Business hours — to be added</li>
            </ul>
          </div>
          <form className="form rv" onSubmit={submit}>
            {sent ? <div className="thanks"><h3>Thank you.</h3><p>Your enquiry has been captured. (Connect this form to your backend or email service to receive it.)</p></div> : <>
              <label>Name<input required name="name" placeholder="Your name" /></label>
              <label>Phone<input required name="phone" type="tel" placeholder="+91" /></label>
              <label>Email<input name="email" type="email" placeholder="you@company.com" /></label>
              <label>Enquiry<textarea required name="msg" rows="4" placeholder="Route, load type, timeline…" /></label>
              <button className="btn solid" type="submit">Send enquiry</button></>}
          </form>
        </section>
      </main>
      <footer>© {new Date().getFullYear()} S.S. Road Carriers. All rights reserved.</footer>
    </div>
  )
}
