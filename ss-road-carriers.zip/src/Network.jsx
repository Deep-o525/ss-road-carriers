const nodes = [
  { id: 'A', x: 140, y: 120, l: 'Hub 01' }, { id: 'B', x: 430, y: 70, l: 'Hub 02' },
  { id: 'C', x: 700, y: 150, l: 'Hub 03' }, { id: 'D', x: 880, y: 330, l: 'Hub 04' },
  { id: 'E', x: 520, y: 330, l: 'Hub 05' }, { id: 'F', x: 220, y: 380, l: 'Hub 06' },
]
const routes = [['A', 'B'], ['B', 'C'], ['C', 'D'], ['D', 'E'], ['E', 'F'], ['F', 'A'], ['B', 'E'], ['C', 'E']]
const get = id => nodes.find(n => n.id === id)
const d = ([a, b]) => { const p = get(a), q = get(b); return `M${p.x} ${p.y} Q${(p.x + q.x) / 2} ${(p.y + q.y) / 2 - 50} ${q.x} ${q.y}` }
export default function Network() {
  return (
    <svg className="net" viewBox="0 0 1000 460" role="img" aria-label="Illustrative logistics network">
      {routes.map((r, i) => <path key={i} className="route" d={d(r)} pathLength="1" />)}
      {routes.map((r, i) => <circle key={'c' + i} r="3.5" fill="#ff6a1a"><animateMotion dur={`${5 + (i % 4)}s`} begin={`${i * 0.7}s`} repeatCount="indefinite" path={d(r)} /></circle>)}
      {nodes.map(n => <g key={n.id} className="node"><circle className="pulse" cx={n.x} cy={n.y} r="6" /><circle cx={n.x} cy={n.y} r="5" fill="#ff6a1a" /><text x={n.x + 14} y={n.y + 4}>{n.l}</text></g>)}
    </svg>
  )
}
