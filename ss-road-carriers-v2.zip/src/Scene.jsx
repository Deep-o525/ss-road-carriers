import { useRef, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js'

export const sceneState = { intro: 0, p: 0, active: true, mx: 0, my: 0, invalidate: null }

const mat = (color, o = {}) => <meshStandardMaterial color={color} roughness={0.5} metalness={0.4} {...o} />
function Box({ p, s, c, o, cast = true }) {
  return <mesh position={p} castShadow={cast} receiveShadow><boxGeometry args={s} />{mat(c, o)}</mesh>
}
function Wheel({ p, spin }) {
  const g = useRef()
  useFrame((_, dt) => { if (g.current) g.current.rotation.x -= dt * 7 })
  return (
    <group position={p}><group ref={g}>
      <mesh rotation={[0, 0, Math.PI / 2]} castShadow><cylinderGeometry args={[0.46, 0.46, 0.4, 28]} />{mat('#0a0a0a', { roughness: 0.9, metalness: 0 })}</mesh>
      <mesh rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.24, 0.24, 0.42, 6]} />{mat('#8a8a8a', { metalness: 0.9, roughness: 0.3 })}</mesh>
    </group></group>
  )
}
const cabGeo = (() => {
  const sh = new THREE.Shape()
  sh.moveTo(1.6, 0.95); sh.lineTo(3.3, 0.95); sh.lineTo(3.3, 1.95); sh.lineTo(3.05, 2.8); sh.lineTo(1.6, 2.8); sh.closePath()
  const g = new THREE.ExtrudeGeometry(sh, { depth: 1.8, bevelEnabled: true, bevelSize: 0.1, bevelThickness: 0.1, bevelSegments: 4, curveSegments: 8 })
  g.translate(0, 0, -0.9); return g
})()
const Paint = ({ c = '#18181a' }) => <meshPhysicalMaterial color={c} metalness={0.85} roughness={0.28} clearcoat={1} clearcoatRoughness={0.12} envMapIntensity={0.9} />
function Truck() {
  const g = useRef(), cam = useRef({ x: 0, y: 0 })
  useFrame((s, dt) => {
    const { p, mx, my, intro } = sceneState, mobile = s.size.width < 800
    const k = 1 - Math.pow(0.001, dt), t = g.current, c = cam.current
    c.x += (mx - c.x) * k; c.y += (my - c.y) * k
    t.rotation.y += ((-0.75 + p * 1.9 + c.x * 0.2) - t.rotation.y) * k
    t.position.x += (((mobile ? 0 : 1.9) + p * 3) - t.position.x) * k
    t.position.y += (((mobile ? -1.5 : -0.2) - p * 0.6) - t.position.y) * k
    t.scale.setScalar(mobile ? 0.6 : 0.95)
    const e = 1 - Math.pow(1 - intro, 3), L = (a, b) => a + (b - a) * e, m = mobile ? 1.35 : 1
    s.camera.position.set(L(12, 6.5 + c.x * 0.9) * 1, L(5.5, 3.2 - c.y * 0.4), L(16, 8.5) * m)
    s.camera.lookAt(0, mobile ? 0.6 : 1.1, 0)
    if (sceneState.active) s.invalidate()
  })
  const beam = x => <mesh key={x} position={[x, 1.55, 6.7]} rotation={[-Math.PI / 2, 0, 0]}><coneGeometry args={[1.5, 6.8, 24, 1, true]} /><meshBasicMaterial color="#ffcf9a" transparent opacity={0.06} side={THREE.DoubleSide} depthWrite={false} blending={THREE.AdditiveBlending} /></mesh>
  const glass = { color: '#04070b', metalness: 1, roughness: 0.04 }
  return (
    <group ref={g}>
      <Box p={[0, 0.75, -0.25]} s={[1.7, 0.3, 7.2]} c="#0e0e0f" />
      <mesh geometry={cabGeo} rotation={[0, -Math.PI / 2, 0]} castShadow receiveShadow><Paint /></mesh>
      <mesh position={[0, 2.33, 3.2]} rotation={[-0.286, 0, 0]}><boxGeometry args={[1.75, 0.9, 0.02]} /><meshStandardMaterial {...glass} /></mesh>
      {[-1, 1].map(x => <Box key={x} p={[x * 1.005, 2.2, 2.45]} s={[0.02, 0.62, 1.15]} c="#04070b" o={{ metalness: 1, roughness: 0.05 }} cast={false} />)}
      {[-0.55, -0.27, 0, 0.27, 0.55].map(x => <Box key={x} p={[x, 1.28, 3.42]} s={[0.1, 0.5, 0.05]} c="#0a0a0a" o={{ metalness: 1, roughness: 0.3 }} cast={false} />)}
      <Box p={[0, 1.05, 3.4]} s={[1.95, 0.22, 0.25]} c="#0b0b0b" />
      <Box p={[0, 0.78, 3.42]} s={[1.5, 0.08, 0.1]} c="#ff6a1a" o={{ emissive: '#ff6a1a', emissiveIntensity: 0.8 }} cast={false} />
      {[-0.72, 0.72].map(x => <Box key={x} p={[x, 1.62, 3.4]} s={[0.4, 0.2, 0.05]} c="#fff" o={{ emissive: '#ffe2c0', emissiveIntensity: 4 }} cast={false} />)}
      {[-1.17, 1.17].map(x => <Box key={x} p={[x, 2.35, 3.0]} s={[0.1, 0.4, 0.22]} c="#0b0b0b" />)}
      {[-1, 1].map(x => <mesh key={x} position={[x * 1.1, 0.6, 1.9]} rotation={[Math.PI / 2, 0, 0]} castShadow><cylinderGeometry args={[0.3, 0.3, 1.2, 20]} /><meshStandardMaterial color="#9a9a9e" metalness={1} roughness={0.25} /></mesh>)}
      {[-1, 1].map(x => <mesh key={'e' + x} position={[x * 0.85, 2.6, 1.45]} castShadow><cylinderGeometry args={[0.07, 0.07, 2.4, 12]} /><meshStandardMaterial color="#b8b8bc" metalness={1} roughness={0.2} /></mesh>)}
      <mesh position={[0, 2.1, -1.1]} castShadow receiveShadow><boxGeometry args={[2.1, 2.6, 5.1]} /><meshPhysicalMaterial color="#26262a" metalness={0.5} roughness={0.42} clearcoat={0.5} /></mesh>
      {[-1.07, 1.07].map(x => <group key={x}>
        <Box p={[x, 1.45, -1.1]} s={[0.02, 0.2, 5.1]} c="#ff6a1a" o={{ emissive: '#ff6a1a', emissiveIntensity: 0.5 }} cast={false} />
        {Array.from({ length: 7 }, (_, i) => <Box key={i} p={[x, 2.1, -3.45 + i * 0.78]} s={[0.03, 2.6, 0.06]} c="#34343a" cast={false} />)}</group>)}
      {[-0.7, 0.7].map(x => <Box key={x} p={[x, 0.95, -3.67]} s={[0.3, 0.14, 0.04]} c="#ff1a1a" o={{ emissive: '#ff1a1a', emissiveIntensity: 3 }} cast={false} />)}
      {[-1, 1].map(x => [2.7, 0.9, -0.1, -2.4, -3.4].map((z, i) => <Wheel key={x + '' + i} p={[x * 0.98, 0.47, z]} />))}
      <pointLight position={[0, 1.5, 4.8]} color="#ffb070" intensity={18} distance={9} />
      {beam(-0.72)}{beam(0.72)}
    </group>
  )
}
function Road() {
  const g = useRef()
  useFrame((_, dt) => { g.current.children.forEach(m => { m.position.z -= dt * 7; if (m.position.z < -16) m.position.z += 32 }) })
  return (
    <>
      <mesh rotation-x={-Math.PI / 2} receiveShadow><planeGeometry args={[60, 60]} /><meshStandardMaterial color="#08080a" roughness={0.22} metalness={0.85} envMapIntensity={0.5} /></mesh>
      <group ref={g}>{Array.from({ length: 22 }, (_, i) => <mesh key={i} position={[(i % 2 ? 3.4 : -3.4), 0.01, -16 + Math.floor(i / 2) * 3]} rotation-x={-Math.PI / 2}><planeGeometry args={[0.12, 1.4]} /><meshBasicMaterial color="#ff6a1a" /></mesh>)}</group>
    </>
  )
}
function Embers({ n = 260 }) {
  const ref = useRef()
  const pos = useMemo(() => { const a = new Float32Array(n * 3); for (let i = 0; i < n; i++) { a[i * 3] = (Math.random() - .5) * 18; a[i * 3 + 1] = Math.random() * 7; a[i * 3 + 2] = (Math.random() - .5) * 18 } return a }, [n])
  useFrame((_, dt) => {
    const a = ref.current.geometry.attributes.position.array
    for (let i = 0; i < n; i++) { a[i * 3 + 1] += dt * 0.35; a[i * 3 + 2] -= dt * 1.2; if (a[i * 3 + 1] > 7) a[i * 3 + 1] = 0; if (a[i * 3 + 2] < -9) a[i * 3 + 2] = 9 }
    ref.current.geometry.attributes.position.needsUpdate = true
  })
  return <points ref={ref}><bufferGeometry><bufferAttribute attach="attributes-position" count={n} array={pos} itemSize={3} /></bufferGeometry><pointsMaterial color="#ff8a3d" size={0.045} transparent opacity={0.8} depthWrite={false} blending={THREE.AdditiveBlending} /></points>
}
export default function Scene({ onReady }) {
  return (
    <Canvas id="scene" shadows frameloop="demand" dpr={[1, 1.5]} camera={{ position: [6.5, 3.2, 8.5], fov: 34 }}
      gl={{ antialias: true, powerPreference: 'high-performance' }}
      onCreated={({ gl, scene, invalidate }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping; gl.toneMappingExposure = 1.1
        { const pm = new THREE.PMREMGenerator(gl); scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture; scene.environmentIntensity = 0.45 }
        scene.fog = new THREE.Fog('#0a0a0b', 9, 26); sceneState.invalidate = invalidate; onReady?.()
      }}>
      <color attach="background" args={['#0a0a0b']} />
      <ambientLight intensity={0.35} />
      <directionalLight position={[5, 8, 4]} intensity={1.6} castShadow shadow-mapSize={[1024, 1024]} shadow-camera-left={-8} shadow-camera-right={8} shadow-camera-top={8} shadow-camera-bottom={-8} />
      <spotLight position={[-6, 5, -5]} color="#ff6a1a" intensity={260} angle={0.6} penumbra={1} />
      <Truck /><Road /><Embers />
    </Canvas>
  )
}
